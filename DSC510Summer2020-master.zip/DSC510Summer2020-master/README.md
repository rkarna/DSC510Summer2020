# DSC510Summer2020
# This space is to attempt to figure out how to push code to github. 
# In this class, this has to be learned, as this is a common activity in the data science world, and this class is about data science.
# print("Hello World") could suffice as a pushed code.
